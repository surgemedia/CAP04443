<footer class="content-info">
  <div class="container">
    <?php echo date('Y'); ?> Copyright Capricorn Photography

  </div>
</footer>
