<?php 
$username    = $args[1];
$email       = $args[2];
$firstname   = $args[3];
$school      = $args[4];
$school_logo = $args[5];
debug($args);

 ?>