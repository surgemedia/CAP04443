<?php 
	$text	=$args[1];
	$class	=$args[2];
?>
<div class="col-lg-6 package-img">
	<i class="<?php echo $class; ?>"></i>
	<div><?php echo $text; ?></div>
</div>