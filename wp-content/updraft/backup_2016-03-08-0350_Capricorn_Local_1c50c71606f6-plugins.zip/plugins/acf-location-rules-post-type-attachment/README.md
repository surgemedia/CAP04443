# ACF Location Rules Post Type Attachment
A plugin to add attachment back as an option in Post Types under Location Rules.

Screenshots
===========

![Fresh widget](/screenshot-1.png?raw=true "Post Type is not equal to attachment")
